<template>
  <div class="sidebar-style">Ako ang Sidebar</div>
</template>

<style scoped>
.sidebar-style {
  display: flex;
  align-items: center;

  background-color: aquamarine;
}
</style>
