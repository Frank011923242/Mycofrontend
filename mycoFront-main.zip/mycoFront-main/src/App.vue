<template>
  <v-app><router-view /></v-app>
</template>
<script>
import { RouterLink, RouterView } from 'vue-router'
</script>
